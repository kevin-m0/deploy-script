import requests
import sys
import json
from datetime import datetime

class TodoAPITester:
    def __init__(self, base_url="https://497dbfec-566d-4dbf-a511-b7260f99458c.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_user_email = f"test_user_{datetime.now().strftime('%H%M%S')}@example.com"
        self.test_user_password = "TestPass123!"
        self.test_user_name = "Test User"
        self.created_todos = []

    def log_test(self, name, success, details=""):
        """Log test results"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED {details}")
        else:
            print(f"❌ {name} - FAILED {details}")
        return success

    def make_request(self, method, endpoint, data=None, expected_status=200):
        """Make HTTP request with proper headers"""
        url = f"{self.api_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'

        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers)

            success = response.status_code == expected_status
            if not success:
                print(f"DEBUG: Expected {expected_status}, got {response.status_code}")
                print(f"DEBUG: Response: {response.text}")
            return success, response
        except Exception as e:
            print(f"Request error: {str(e)}")
            return False, None

    def test_user_registration(self):
        """Test user registration"""
        data = {
            "name": self.test_user_name,
            "email": self.test_user_email,
            "password": self.test_user_password
        }
        
        success, response = self.make_request("POST", "auth/register", data, 200)
        if success:
            return self.log_test("User Registration", True, f"- User {self.test_user_email} registered")
        else:
            error_msg = response.json().get('detail', 'Unknown error') if response else 'No response'
            return self.log_test("User Registration", False, f"- {error_msg}")

    def test_duplicate_registration(self):
        """Test duplicate user registration should fail"""
        data = {
            "name": self.test_user_name,
            "email": self.test_user_email,
            "password": self.test_user_password
        }
        
        success, response = self.make_request("POST", "auth/register", data, 400)
        if success:
            return self.log_test("Duplicate Registration Prevention", True, "- Correctly rejected duplicate email")
        else:
            return self.log_test("Duplicate Registration Prevention", False, "- Should have rejected duplicate email")

    def test_user_login(self):
        """Test user login"""
        data = {
            "email": self.test_user_email,
            "password": self.test_user_password
        }
        
        success, response = self.make_request("POST", "auth/login", data, 200)
        if success and response:
            response_data = response.json()
            if 'access_token' in response_data:
                self.token = response_data['access_token']
                return self.log_test("User Login", True, "- Token received")
            else:
                return self.log_test("User Login", False, "- No token in response")
        else:
            error_msg = response.json().get('detail', 'Unknown error') if response else 'No response'
            return self.log_test("User Login", False, f"- {error_msg}")

    def test_invalid_login(self):
        """Test login with invalid credentials"""
        data = {
            "email": self.test_user_email,
            "password": "wrongpassword"
        }
        
        success, response = self.make_request("POST", "auth/login", data, 401)
        if success:
            return self.log_test("Invalid Login Prevention", True, "- Correctly rejected invalid credentials")
        else:
            return self.log_test("Invalid Login Prevention", False, "- Should have rejected invalid credentials")

    def test_get_user_info(self):
        """Test getting current user info"""
        if not self.token:
            return self.log_test("Get User Info", False, "- No token available")
        
        success, response = self.make_request("GET", "auth/me", expected_status=200)
        if success and response:
            user_data = response.json()
            if user_data.get('email') == self.test_user_email:
                self.user_id = user_data.get('id')
                return self.log_test("Get User Info", True, f"- User: {user_data.get('name')}")
            else:
                return self.log_test("Get User Info", False, "- Wrong user data returned")
        else:
            return self.log_test("Get User Info", False, "- Failed to get user info")

    def test_unauthorized_access(self):
        """Test accessing protected endpoint without token"""
        # Temporarily remove token
        temp_token = self.token
        self.token = None
        
        success, response = self.make_request("GET", "auth/me", expected_status=403)
        
        # Restore token
        self.token = temp_token
        
        if success:
            return self.log_test("Unauthorized Access Prevention", True, "- Correctly rejected request without token")
        else:
            return self.log_test("Unauthorized Access Prevention", False, "- Should have rejected request without token")

    def test_create_todo(self):
        """Test creating a todo"""
        if not self.token:
            return self.log_test("Create Todo", False, "- No token available")
        
        data = {
            "title": "Buy groceries",
            "description": "Milk, eggs, bread"
        }
        
        success, response = self.make_request("POST", "todos", data, 200)
        if success and response:
            todo_data = response.json()
            if todo_data.get('title') == data['title']:
                self.created_todos.append(todo_data['id'])
                return self.log_test("Create Todo", True, f"- Todo created: {todo_data['title']}")
            else:
                return self.log_test("Create Todo", False, "- Wrong todo data returned")
        else:
            return self.log_test("Create Todo", False, "- Failed to create todo")

    def test_create_todo_without_description(self):
        """Test creating a todo without description"""
        if not self.token:
            return self.log_test("Create Todo (No Description)", False, "- No token available")
        
        data = {
            "title": "Call dentist"
        }
        
        success, response = self.make_request("POST", "todos", data, 200)
        if success and response:
            todo_data = response.json()
            if todo_data.get('title') == data['title']:
                self.created_todos.append(todo_data['id'])
                return self.log_test("Create Todo (No Description)", True, f"- Todo created: {todo_data['title']}")
            else:
                return self.log_test("Create Todo (No Description)", False, "- Wrong todo data returned")
        else:
            return self.log_test("Create Todo (No Description)", False, "- Failed to create todo")

    def test_get_todos(self):
        """Test getting user's todos"""
        if not self.token:
            return self.log_test("Get Todos", False, "- No token available")
        
        success, response = self.make_request("GET", "todos", expected_status=200)
        if success and response:
            todos = response.json()
            if isinstance(todos, list) and len(todos) >= 2:
                return self.log_test("Get Todos", True, f"- Retrieved {len(todos)} todos")
            else:
                return self.log_test("Get Todos", False, f"- Expected at least 2 todos, got {len(todos) if isinstance(todos, list) else 'invalid response'}")
        else:
            return self.log_test("Get Todos", False, "- Failed to get todos")

    def test_update_todo(self):
        """Test updating a todo (mark as completed)"""
        if not self.token or not self.created_todos:
            return self.log_test("Update Todo", False, "- No token or todos available")
        
        todo_id = self.created_todos[0]
        data = {"completed": True}
        
        success, response = self.make_request("PUT", f"todos/{todo_id}", data, 200)
        if success and response:
            todo_data = response.json()
            if todo_data.get('completed') == True:
                return self.log_test("Update Todo", True, f"- Todo marked as completed")
            else:
                return self.log_test("Update Todo", False, "- Todo not marked as completed")
        else:
            return self.log_test("Update Todo", False, "- Failed to update todo")

    def test_delete_todo(self):
        """Test deleting a todo"""
        if not self.token or len(self.created_todos) < 2:
            return self.log_test("Delete Todo", False, "- No token or insufficient todos available")
        
        todo_id = self.created_todos[1]  # Delete the second todo
        
        success, response = self.make_request("DELETE", f"todos/{todo_id}", expected_status=200)
        if success:
            return self.log_test("Delete Todo", True, "- Todo deleted successfully")
        else:
            return self.log_test("Delete Todo", False, "- Failed to delete todo")

    def test_forgot_password(self):
        """Test forgot password functionality"""
        data = {"email": self.test_user_email}
        
        success, response = self.make_request("POST", "auth/forgot-password", data, 200)
        if success:
            return self.log_test("Forgot Password", True, "- Reset request processed")
        else:
            return self.log_test("Forgot Password", False, "- Failed to process reset request")

    def test_invalid_todo_operations(self):
        """Test invalid todo operations"""
        if not self.token:
            return self.log_test("Invalid Todo Operations", False, "- No token available")
        
        # Test accessing non-existent todo
        fake_todo_id = "non-existent-id"
        success, response = self.make_request("PUT", f"todos/{fake_todo_id}", {"completed": True}, 404)
        
        if success:
            return self.log_test("Invalid Todo Operations", True, "- Correctly rejected non-existent todo access")
        else:
            return self.log_test("Invalid Todo Operations", False, "- Should have rejected non-existent todo access")

    def run_all_tests(self):
        """Run all tests in sequence"""
        print("🚀 Starting Todo API Tests...")
        print(f"Testing against: {self.base_url}")
        print("=" * 60)

        # Authentication Tests
        print("\n📝 AUTHENTICATION TESTS")
        print("-" * 30)
        self.test_user_registration()
        self.test_duplicate_registration()
        self.test_user_login()
        self.test_invalid_login()
        self.test_get_user_info()
        self.test_unauthorized_access()

        # Todo Tests
        print("\n📋 TODO TESTS")
        print("-" * 30)
        self.test_create_todo()
        self.test_create_todo_without_description()
        self.test_get_todos()
        self.test_update_todo()
        self.test_delete_todo()
        self.test_invalid_todo_operations()

        # Additional Tests
        print("\n🔐 ADDITIONAL TESTS")
        print("-" * 30)
        self.test_forgot_password()

        # Results
        print("\n" + "=" * 60)
        print(f"📊 TEST RESULTS: {self.tests_passed}/{self.tests_run} tests passed")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
            return 0
        else:
            print(f"⚠️  {self.tests_run - self.tests_passed} tests failed")
            return 1

def main():
    tester = TodoAPITester()
    return tester.run_all_tests()

if __name__ == "__main__":
    sys.exit(main())